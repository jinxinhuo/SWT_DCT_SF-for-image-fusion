function R = fusionrule(Y0, Y01,I1,I2)
Y0=SFR(Y0);
Y01=SFR(Y01);       
[p,q]=size(I1);
      for i=1:p
          for j=1:q             
                if abs(Y0(i,j)-Y01(i,j))<=0.015
                   R(i,j)=(I1(i,j)+I2(i,j))/2;      
                end 
                if abs(Y0(i,j)-Y01(i,j))>0.015&&Y0(i,j)>Y01(i,j)
                    R(i,j)=I1(i,j);
                end
                if abs(Y0(i,j)-Y01(i,j))>0.015&& Y0(i,j)<Y01(i,j)
                    R(i,j)=I2(i,j);
                end 
       end
      end