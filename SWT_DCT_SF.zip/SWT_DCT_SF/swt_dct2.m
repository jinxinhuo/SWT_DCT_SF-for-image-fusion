function imf=swt_dct2(M1,M2)



[m,n]=size(M1);
bs=4;
for i=1:bs:m
    for j=1:bs:n
        cb1 = M1(i:i+bs-1,j:j+bs-1);
        cb2 = M2(i:i+bs-1,j:j+bs-1);
         CB1=dct2(cb1);
         CB2=dct2(cb2);
         CBF= fusionrule(CB1,CB2,CB1,CB2);
        cbf=idct2(CBF);
        imf(i:i+bs-1,j:j+bs-1)=cbf;
        im1(i:i+bs-1,j:j+bs-1)=CB1;
        im2(i:i+bs-1,j:j+bs-1)=CB2;
        im3(i:i+bs-1,j:j+bs-1)=CBF;
        
    end
end

figure,imshow(M1,[]);
figure,imshow(M2,[]);
figure,imshow(imf,[]);

figure,imshow(im1,[]);
           figure(1231);
           imagesc(M1)
           axis off
           axis image
figure,imshow(im2,[]);
           figure(1232);
           imagesc(M2)
           axis off
           axis image
figure,imshow(im3,[]);
           figure(1233);
           imagesc(imf)
           axis off
           axis image
end
