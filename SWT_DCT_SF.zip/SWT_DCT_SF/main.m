clc;
clear all;
close all;
home
%%
% If you use this MATLAB code please reference the following paper. 
%Jin X, Jiang Q, Yao S, et al. Infrared and Visual Image Fusion Method 
% Based on Discrete Cosine Transform and Local Spatial Frequency in 
% Discrete Stationary Wavelet Transform Domain, 88(2018): 1-12, 
% Infrared Physics & Technology,
% https://www.researchgate.net/profile/Jin_Xin24



im1=imread('hwj1.jpg');
im2=imread('hwj2.jpg');

% im1=double(im1);        
% im2=double(im2); 
type='haar';
n=3;
[ca1,ch1,cv1,cd1] = swt2(im1,n,type);
[ca2,ch2,cv2,cd2] = swt2(im2,n,type);
%db1','db2','db3','db4','db5','db6','db7','db8','db9','db10','coif1','coif2','coif3','coif4','coif5'...
%,'bior1.1','bior1.3','bior1.5','bior2.2','bior2.4','bior2.6','bior2.8','bior3.3','bior3.5','bior3.7','bior3.9','bior4.4','bior5.5','bior6.8'...
%,'rbio1.1','rbio1.3','rbio1.5','rbio2.2','rbio2.4','rbio2.6','rbio2.8','rbio3.3','rbio3.5','rbio3.7','rbio3.9','rbio4.4','rbio5.5','rbio6.8'...
%,'dmey'

[m,n,q]=size(ca1);
for qq=1:q
ca(:,:,qq)=swt_dct2(ca1(:,:,qq),ca2(:,:,qq));
ch(:,:,qq)=swt_dct2(ch1(:,:,qq),ch2(:,:,qq));
cv(:,:,qq)=swt_dct2(cv1(:,:,qq),cv2(:,:,qq));
cd(:,:,qq)=swt_dct2(cd1(:,:,qq),cd2(:,:,qq));
end
R=iswt2(ca,ch,cv,cd,type);

figure(121),imshow(im1,[]);
figure(122),imshow(im2,[]);
figure(1230),imshow(uint8(R),[]);

R=uint8(R);
imwrite(R,'main.tif');
R=255*im2double(R);

m=mean2(R)
Qabf1= Qabf(im1, im2, R);
MI=mutural_information(im1,im2,R,256)
std= std2(R)
SF1=SF(uint8(R))
EN1=EN(R)
